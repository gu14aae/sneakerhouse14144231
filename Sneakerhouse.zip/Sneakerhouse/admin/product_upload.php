<?php 

               include ('header.php');

               include ('sidebar.php');

               include ('db.php');

                $query = "SELECT * FROM `brands`";

                $get_brand = mysqli_query($con,$query) or die(mysql_error());

                $query1 = "SELECT * FROM `categories`";

                $get_category = mysqli_query($con,$query1) or die(mysql_error());

                                                                  

                if (!empty($_POST['product_name'])  && !empty($_POST['product_price'])) 

                {

                   

                       

                           $product_name= $_POST['product_name'];

                           $product_brand= $_POST['brand'];

                           $product_category= $_POST['category'];

                           $product_price= $_POST['product_price'];

                           $product_desc= $_POST['product_desc'];

                           $product_key=  $_POST['product_key'];

                           $product_img= basename($_FILES["product_image"]["name"]);



                           $target_dir = "../product_images/";

                           $target_file = $target_dir . basename($_FILES["product_image"]["name"]);

                           $uploadOk = 1;

                           $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

                          

                    if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file))

                     {

                        



                      

                          $query2= "INSERT INTO products (product_cat, product_brand, product_title, product_price, product_desc,  product_image,product_keywords)

                                       VALUES ('$product_category','$product_brand','$product_name','$product_price','$product_desc','$product_img','$product_key')";

                                       $query2;

                                 

                        if(mysqli_query($con,$query2))

                        {



                              $msg=" Product Added Succesfully";

                        } else

                          {

                              $msg=" Something went wrong";

                          }



                     }

                       else

                        {

                            echo "Sorry, there was an error uploading your file.";

                        }





                }


                          



                                                              

?>

  

  <div class="content-wrapper">

    <!-- Content Header (Page header) -->

<!--     <section class="content-header">

      <h1>

        Dashboard

        <small>Control panel</small>

      </h1>

      <ol class="breadcrumb">

        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>

        <li class="active">Dashboard</li>

      </ol>

    </section> -->



    <!-- Main content -->

    <div class="register-box-body">

    <p class="login-box-msg">Add Product</p>

      <h3 style="color:red;>"> <?php if(!empty($msg)){

           echo $msg;



       }

       ?></h3>

    <form  method="post"  enctype="multipart/form-data">

     

      <div class="form-group has-feedback">

        <label>Product Name</label>

         <input type="text"  id="product_name" name="product_name" placeholder="Product Name" class="form-control" required="">

      </div>

        <div class="form-group has-feedback">

          <label>Brand</label>

        <select name="brand"   id="brand" class="form-control-sm form-control">

                                                          

                                                             <?php foreach($get_brand as $res) { 

                                                              

                                                            ?>



                                                        <option value="<?php echo $res['brand_id']; ?>"><?php echo $res['brand_title']; ?></option>



                                                        <?php } ?>

                                                    </select>

      </div>

      <div class="form-group has-feedback">

        <label>Category</label>

        <select name="category"   id="category" class="form-control-sm form-control">

                                                         

                                                           <?php foreach($get_category as $res) { 

                                                              

                                                            ?>



                                                        <option value="<?php echo $res['cat_id']; ?>"><?php echo $res['cat_title']; ?></option>



                                                        <?php } ?>

                                                    </select>

      </div>



      <div class="form-group has-feedback">

        <label>Product Description</label>

       <textarea   id="product_desc" name="product_desc" placeholder="product_desc" class="form-control" required=""></textarea>

      </div>



       <div class="form-group has-feedback">

        <label>Product Keywords</label>

       <textarea   id="product_key" name="product_key" placeholder="product_key" class="form-control" required=""></textarea>

      </div>



       <div class="form-group has-feedback">

        <label>Product Price</label>

       <input type="text"  id="product_price" name="product_price" placeholder="Regular price" class="form-control" required="">

      </div>



       <div class="form-group has-feedback">

       <label>Product Image</label> <input type="file"  id="product_image" name="product_image" class="form-control-file" required="">

      </div>

      

     

      <div class="row">

        <div class="col-xs-8">

         

        </div>

        <!-- /.col -->

        <div class="col-xs-4">

          <button type="submit" class="btn btn-primary btn-block btn-flat" >Add Product</button>

        </div>

        <!-- /.col -->

      </div>

    </form>



   



    

  </div>

    <!-- /.content -->

  </div>

  <!-- /.content-wrapper -->

 

<!-- ./wrapper -->

<?php include ('footer.php');?>