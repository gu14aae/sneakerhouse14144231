<?php 

 include ('header.php');

 include ('sidebar.php');

?>

  <!-- Left side column. contains the logo and sidebar -->

 



  <!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper">

    <!-- Content Header (Page header) -->

    <section class="content-header">

      <h1>

        Dashboard

        <small>Control panel</small>

      </h1>

      <ol class="breadcrumb">

        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>

        <li class="active">Dashboard</li>

      </ol>

    </section>



    <!-- Main content -->
<div class="container" >

    <div class="row">

      <div class="col-md-1"></div>

      

 <div class="col-lg-10">
  <h3><b>Hello</b></h3>
<p ><span style="font-style: italic;font-size: 17px;text-align: justify;">Welcome to my Ecommerce Website, over the past several years, Ecommerce has transformed how people buy and sell online. The Internet provides a fast and easy way for people to purchase things without having to visit an actual store. An online store can reach customers anywhere in the world. On my ecommerce website, we will be selling Sports Trainers and fashion Sneakers. Customers will be able to register to become members, so that we can send them product updates, promotions, new instructions regarding my ecommerce website. There will be product images so that custimers can see the products on display, The products will have description so that customers know everything about the product to help the customer's decision making easier The products will have prices tagged to them so know how much the product cost. In the customer accounts, they will be able to view orders. They will be able to login and log out. click on products, click on brands to select and filter what they want to buy. They will be able to add products to cart and have the option to continue shopping or go to check out once shopping is concluded, customers will be able to check out and make payments via paypal. The website will be coded in HTML, CSS and the database will be MySQL. It will also have a blog built on wordpress platform</span></p>

</a>


</div>

      

      <div class="col-md-1"></div>

    </div>

  </div>
   

    <!-- /.content -->

  </div>

  <!-- /.content-wrapper -->

  

<?php include ('footer.php');?>