<?php 

 include ('header.php');

 include ('sidebar.php');
  include ('db.php');
$query = "SELECT date FROM `orders`";

                $get_date = mysqli_query($con,$query) or die(mysql_error());

?>

  <!-- Left side column. contains the logo and sidebar -->

 



  <!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper">

    <!-- Content Header (Page header) -->
   
    <section class="content-header">

      <h1>

        Dashboard

       

      </h1>

      <ol class="breadcrumb">

        <li><a href="#"><i class="fa fa-dashboard"></i> Admin</a></li>

        <li class="active">Order</li>

      </ol>

    </section>



    <!-- Main content -->
<div class="container" >

    <div class="row">

      <div class="col-md-12"></div>

      

 <div class="col-lg-10">
  <h3 style="text-align: center;background: wheat;padding: 4px;">Orders</h3> 
  <?php 
$orders_list = "SELECT o.order_id,o.user_id,o.product_id,o.qty,o.trx_id,o.p_status,o.date,p.product_title,p.product_price,p.product_image FROM orders o,products p WHERE  o.product_id=p.product_id ORDER BY o.product_id DESC";


              $query = mysqli_query($con,$orders_list);

              if (mysqli_num_rows($query) > 0) {

                while ($row=mysqli_fetch_array($query)) {

                  ?>

                    <div class="row">

                      <div class="col-md-3">

                        <img style="float:right;" src="../product_images/<?php echo $row['product_image']; ?>" class="img-responsive img-thumbnail"/>

                      </div>

                      <div class="col-md-9">

                       
<table>
                         <tr><td> Product Name:<b><?php echo $row["product_title"]; ?></b> </td></tr>

                          <tr><td>Product Price:</td><td><b><?php echo "$ ".$row["product_price"]; ?></b></td></tr>

                          <tr><td>Quantity:</td><td><b><?php echo $row["qty"]; ?></b></td></tr>
                          <tr><td>Date:</td><td><b><?php echo  date('M/d/Y', $row["date"]); ?></b></td></tr>

                          <tr><td>Transaction Id:</td><td><b><?php echo $row["trx_id"]; ?></b></td></tr>
                          <tr><td>Status:</td><td><b><?php echo $row["p_status"]; ?></b></td></tr>

                        </table>

                      </div>

                    </div>

                  <?php

                }

              }

            ?>
</div>

      

      <div class="col-md-1"></div>

    </div>

  </div>
   

    <!-- /.content -->

  </div>

  <!-- /.content-wrapper -->

  

<?php include ('footer.php');?>