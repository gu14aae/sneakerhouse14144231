<?php 

               include ('header.php');

               include ('sidebar.php');

               include ('db.php');

               

                                                                  

                if (!empty($_POST['brand']))

                {

                   

                       

                           $brand= $_POST['brand'];

                          

                          $query= "INSERT INTO brands (brand_title)

                                       VALUES ('$brand')";

                                       $query2;

                                 

                        if(mysqli_query($con,$query))

                        {



                              $msg= "New Brand ".$brand." Created Sucessfully";

                        } else

                          {

                              $msg=" Something went wrong";

                          }

                }

                  if (!empty($_POST['category']))

                {

                   

                       

                           $category= $_POST['category'];

                          

                          $query1= "INSERT INTO categories (cat_title)

                                       VALUES ('$category')";

                                       $query1;

                                 

                        if(mysqli_query($con,$query1))

                        {



                              $msg1= "New Category ".$category."  Created Sucessfully";

                        } else

                          {

                              $msg1=" Something went wrong";

                          }

                }                                                  

?>

  

  <div class="content-wrapper">

    <!-- Content Header (Page header) -->

<!--     <section class="content-header">

      <h1> 

        Dashboard

        <small>Control panel</small>

      </h1>

      <ol class="breadcrumb">

        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>

        <li class="active">Dashboard</li>

      </ol>

    </section> -->



    <!-- Main content -->

    <div class="register-box-body">

    <p class="login-box-msg">Add Brand</p>

      <h3 style="color:red;>"> <?php if(!empty($msg)){

           echo $msg;



       }

       ?></h3>

    <form  method="post">

     

      <div class="form-group has-feedback">

        <label>Brand Name</label>

         <input type="text"  id="brand" name="brand" placeholder="Brand Name" class="form-control" required="">

      </div>

      

      

     

      <div class="row">

        <div class="col-xs-8">

         

        </div>

        <!-- /.col -->

        <div class="col-xs-4">

          <button type="submit" class="btn btn-primary btn-block btn-flat" >Add Brand</button>

        </div>

        <!-- /.col -->

      </div>

    </form>



   



    

  </div>

  <div class="register-box-body">

    <p class="login-box-msg">Add Category</p>

      <h3 style="color:red;>"> <?php if(!empty($msg1)){

           echo $msg1;



       }

       ?></h3>

    <form  method="post">

     

      <div class="form-group has-feedback">

        <label>Category Name</label>

         <input type="text"  id="category" name="category" placeholder="Category Name" class="form-control" required="">

      </div>

      

      

     

      <div class="row">

        <div class="col-xs-8">

         

        </div>

        <!-- /.col -->

        <div class="col-xs-4">

          <button type="submit" class="btn btn-primary btn-block btn-flat" >Add Category</button>

        </div>

        <!-- /.col -->

      </div>

    </form>



   



    

  </div>

    <!-- /.content -->

  </div>

  <!-- /.content-wrapper -->




<!-- ./wrapper -->

<?php include ('footer.php');?>