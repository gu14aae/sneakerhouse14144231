<?php

$servername = "localhost";
$username = "landmp6q_khanstr";
$password = "zE?y4={jRoXC";
$db = "landmp6q_khanStore";

// Create connection
$con = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}


?>